import static org.junit.Assert.*;
import java.util.Arrays;
import org.junit.Before;
import org.junit.Test;

/**
 * For a bonus 2 marks explain why each test either passes or fails, please do this
 * in a separate text document submitted to Canvas
 */
public class BonusTest {

    int [] A = {4, 5, 1, 3, 9, -1, 0};
    int [] ASorted = {-1, 0, 1, 3, 4, 5, 9};
    int [] B;

    @Before
    public void setUp() throws Exception {
        B = A.clone();
        Arrays.sort(B);
    }

    @Test
    public void testSortIntArrayEquals() {
        assertTrue(Arrays.equals(ASorted,B));
        //printArray(ASorted, B); 
    }
    @Test
    public void testSortIntAssertArrayEquals() {
        assertArrayEquals(ASorted,B);
        printArray(ASorted, B); 
    }
    @Test
    public void testSortIntEquals() {
        assertTrue(B.equals(ASorted));
        //printArray(ASorted, B); 
    }
    @Test
    public void testSortIntAssertEquals() {
        assertEquals(ASorted, B);
        //printArray(ASorted, B); 
    }
    @Test
    public void testSortIntAssertDeepEquals() {        
        Integer[] ASortedo = new Integer[ASorted.length];
        for (int i=0; i < ASorted.length ; i++) ASortedo[i] = ASorted[i];
        Integer[] Bo = new Integer[B.length];
        for (int i=0; i < B.length ; i++) Bo[i] = B[i];
        assertTrue(Arrays.deepEquals(ASortedo,Bo));
    }
    public void printArray(int[] a, int[] b) {
    	System.out.println("ASorted: ");
    	for (int i = 0; i < a.length; i++) {
    		System.out.print(a[i] + ", ");
    	}
    	System.out.println(" ");
    	System.out.println("B: ");
    	for (int j = 0; j < b.length; j++) {
    		System.out.print(b[j] + ", ");
    	}
    }
}
