import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * TODO: complete the following test, base the tests off of what was shown earlier test classes
 */
public class StudentTest {

    Student bill;
    Student ben;
    Student bob;

    @Before
    public void initialize() throws Exception{
        bob = new Student(18, "Bob Maher", new String []{"COSC 222","COSC 311", "MATH 200", "MATH 220"});
        bill = new Student(19, "Bill Cosby", new String []{"COSC 222", "COSC 404", "ENGL 112"});
        ben = new Student(24, "Ben Mckenny", new String []{"COSC 222", "COSC 111", "MATH 200", "PHYS 101"});
    }
    @Test
    public void testGetClasses() throws Exception {
    	String[] a = new String[] {"COSC 222","COSC 311", "MATH 200", "MATH 220"};
    	String[] b = new String[] {"COSC 222", "COSC 404", "ENGL 112"};
    	String[] c = new String[] {"COSC 222", "COSC 111", "MATH 200", "PHYS 101"};
    	assertArrayEquals(bob.getClasses(), a);
    	assertArrayEquals(bill.getClasses(), b);
    	assertArrayEquals(ben.getClasses(), c); 
    	
        
    }

    @Test
    public void testGetAge() throws Exception {
    	assertEquals(bob.getAge(), 18);
    	assertEquals(bill.getAge(), 19);
    	assertEquals(ben.getAge(), 24);
    	
    }
}