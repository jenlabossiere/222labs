import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * the Junit test class for the administration class, for this one we included two tests
 * for each method to adequately test them for the expected and corner case
 */
public class AdministrationTest {
    Administration admin = new Administration();

    UniClass COSC222;
    UniClass MATH200;

    Teacher Andrew;
    Teacher Jennifer;

    Student bill;
    Student ben;
    Student bob;

    @Before
    public void initialize() throws Exception{
        bob = new Student(18, "Bob Maher", new String []{"COSC 222","COSC 311", "MATH 200", "MATH 220"});
        bill = new Student(19, "Bill Cosby", new String []{"COSC 222", "COSC 404", "ENGL 112"});
        ben = new Student(24, "Ben Mckenny", new String []{"COSC 222", "COSC 111", "MATH 200", "PHYS 101"});

        Andrew = new Teacher(36,"Andrew Peterson",  new String []{"COSC 222", "COSC 404", "COSC 111"}, "Computer Science");
        Jennifer = new Teacher(36,"Jennifer Lopez",  new String []{"MATH 200", "MATH 220"}, "Mathematics");

        COSC222 = new UniClass(new Student[]{bob,bill,ben}, Andrew, "COSC 222");
        MATH200 = new UniClass(new Student[]{bob,ben}, Jennifer, "MATH 200");
    }

    /**
     * trying to test whether intersection does what it should
     */
    @Test
    public void testIntersection1() throws Exception{
        ArrayList<Student> list = new ArrayList<>(Arrays.asList(bob, ben));

        ArrayList<Student> results = admin.intersection(COSC222.getStudents(), MATH200.getStudents());
        assertTrue(list.containsAll(results) && results.containsAll(list));
    }

    /**
     * notice how this test fails, I may want to alter the intersection method to account for
     * this in some way. (Hint: you are going to do that)
     */
    @Test
    public void testIntersection2(){
        ArrayList<Student> list = new ArrayList<>(Arrays.asList());

        ArrayList<Student> results = admin.intersection(COSC222.getStudents(), new Student[]{});
        assertTrue(list.containsAll(results) && results.containsAll(list));

    }

    //TODO: write 2 test cases for orderStudents1 consider how the previous tests where formatted
    //for this you may want to think of how a change in the parameters may alter the returned value
    //(i.e. think about corner cases)
    @Test
    public void testOrderStudents1() throws Exception{
    	ArrayList<Student> list = new ArrayList<>(Arrays.asList(bob, ben));

        ArrayList<Student> results = admin.orderStudents(COSC222, 'M');
        assertTrue(list.containsAll(results) && results.containsAll(list));
    }

    @Test
    public void testOrderStudents2() throws Exception{
    	ArrayList<Student> list = new ArrayList<>(Arrays.asList(bill));

        ArrayList<Student> results = admin.orderStudents(COSC222, 'C');
        assertTrue(list.containsAll(results) && results.containsAll(list));

    }

}